/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   tiles.h                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nnuno-ca <nnuno-ca@student.42porto.com>    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/11/23 18:38:04 by nnuno-ca          #+#    #+#             */
/*   Updated: 2023/01/28 13:54:57 by nnuno-ca         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef IMAGES_H
# define IMAGES_H

# define WALL_TILE "./assets/wall.xpm"
# define FLOOR_TILE "./assets/floor.xpm"
# define PLAYER_TILE "./assets/player.xpm"
# define ENEMY_TILE "./assets/ghost.xpm"
# define COLLECTIBLE_TILE "./assets/coin.xpm"
# define EXIT_TILE "./assets/exit.xpm"

# define TILE_SIZE 64

#endif